function prob = Lambda(z)

prob    = exp(z) ./ (1 + exp(z));

return